package instructor;

import java.util.Arrays;

public class SplittingHeadache {
	public static void main(String[] args) {
		String days = "Mon Tue Wed Thu Fri";
		String theDays [] = days.split(" ");
		//System.out.println(theDays[2]);
		for(String gibberish : theDays){
			System.out.println(gibberish);
		}
		System.out.println(Arrays.toString(theDays));
	}
}
