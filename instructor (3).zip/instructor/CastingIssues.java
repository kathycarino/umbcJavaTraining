package instructor;

public class CastingIssues {
	public static void main(String[] args) {
//		byte b = 127;
//		b = (byte) (b + 1);
//		System.out.println(b);
		
		byte b = 1;
		//b = b + 1;
		b++;
		System.out.println(b);
		
		
		int x = 10;
		double d = 10.0;
		System.out.println(x == d);
		
	}
}
