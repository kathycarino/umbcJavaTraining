package instructor.datastructures;
public class IntList extends DataStructure {
    private int capacity;
    private int data [];

    public IntList(){
    	this(100);
    }
    public IntList(int capacity){
        this.capacity = capacity;
        data = new int[capacity];
    }

    public boolean addElement(int element){
    	boolean result = false;
        if(size < capacity){
            data[size] = element;
            size++;
            result =  true;
        }
        
        return result;
    }

    public String toString(){
        StringBuffer sb = new StringBuffer(size * 6);
        for(int i = 0; i < size; i++){
            sb.append(data[i]);
            if(i < size -1)
                sb.append(", ");
        }
        return sb.toString();
    }
}