package instructor.datastructures;
public class DataStructureTest {
    public static void main(String args[]) throws Exception{
    	Class c = Class.forName(args[0]);
    	
        DataStructure myData = (DataStructure) c.newInstance();
        int x;
        for(int i = 1; i < args.length; i++){
            x = Integer.parseInt(args[i]);
            myData.addElement(x);
        }
        System.out.println("Size =" + myData.size());
        System.out.println(myData);
    }
}
