package instructor;
public class PointTest {
    public static void main(String args[]) {
        Point p1 = new Point(1, 7);
        Object p2 = new Point(1, 7);
        System.out.println(p1.equals(p2));
       
    }
}