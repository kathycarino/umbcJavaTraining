package instructor.inheritance.ex2;

import java.util.ArrayList;


public class EasyPlanner{
    private ArrayList sd;

    public EasyPlanner(int capacity){
        this.sd = new ArrayList(capacity);
    }


    public int getSize(){
        return sd.size();
    }

    public void addDate(SimpleDate d){
    	sd.add(d);
    }

    public String toString(){
        StringBuilder sb = new StringBuilder(128 * sd.size());
        for (Object o : sd) {
			sb.append(o).append('\n');
		}
        return sb.toString();
    }

    public ArrayList getAppointments(){
        ArrayList apps = new ArrayList(sd.size());
        for(Object o : sd){
        	if( o instanceof Appointment)
        		apps.add(o);
        }
        
        return apps;
    }

    public Holiday [] getHolidays(){
        // **** TODO ***
        return null;
    }
}