package instructor.inheritance.ex2;

import sun.print.resources.serviceui;

public class Planner{
    private SimpleDate sd [];
    private int capacity;
    private int size;

    public Planner(int capacity){
        this.capacity = capacity;
        this.sd = new SimpleDate[this.capacity];
        this.size = 0;
    }

    public int getCapacity(){
        return capacity;
    }

    public int getSize(){
        return size;
    }

    public void addDate(SimpleDate d){
    	if(size >= capacity){
    		capacity *= 2;
    		SimpleDate temp [] = new SimpleDate[capacity];
    		System.arraycopy(sd, 0, temp, 0, size);
    		sd = temp;
    	}
        sd[size] = d;
        size++;
    }

    public String toString(){
        StringBuilder sb = new StringBuilder(128 * size);
        for (int i = 0; i < size; i++) {
			sb.append(sd[i]).append('\n');
		}
        return sb.toString();
    }

    public Appointment [] getAppointments(){
    	int index = 0;
        Appointment apps [] = new Appointment[size];
        for(int i = 0; i < size; i++){
        	if( sd[i] instanceof Appointment)
        		apps[index++] = (Appointment) sd[i];
        }
        Appointment realSize[] = new Appointment[index];
        System.arraycopy(apps, 0, realSize, 0, index);
        return realSize;
    }

    public Holiday [] getHolidays(){
        // **** TODO ***
        return null;
    }
}