package instructor;

public class LackOfAnything {
	int x;
	public LackOfAnything(int a){
		int x = 99;
		this.x = x;
	}
}
