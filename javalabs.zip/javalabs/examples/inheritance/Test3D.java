package examples.inheritance;
public class Test3D {
    public static void main(String args[]) {
        Point3D p1 = new Point3D(1,2,3);
        System.out.println(p1);
        System.out.println(p1.getXc());
        System.out.println(p1.getYc());
        System.out.println(p1.getZc());
    }
}