package examples.intro;
public class AddAgain {
    public static void main(String args[]) {
        int x = 10, y = 20;
        System.out.print(x + " + " + y);
        System.out.println(" is " + ( x + y));
    }
}