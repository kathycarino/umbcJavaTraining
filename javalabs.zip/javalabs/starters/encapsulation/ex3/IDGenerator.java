package starters.encapsulation.ex3;
public class IDGenerator{
    private String prefix;
    private int number;

    // supplies a default prefix
    // supplies a default starting number
    public IDGenerator() {
        // **** TODO ***
    }

    // user supplies prefix
    // supplies a default starting number
    public IDGenerator(String prefix){
        // **** TODO ***
    }

    // user supplies prefix
    // user supplies starting number
    public IDGenerator(String prefix, int start){
        // **** TODO ***
    }

    // issue an id and increment number
    public String issueNext(){
        // **** TODO ***
        return null;
    }

    // return id but do not increment
    public String viewNext(){
        // **** TODO ***
        return null;
    }
}