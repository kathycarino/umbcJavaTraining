package starters.exceptions.ex2;
public class SimpleDateTester{
    public static void main(String args[]){
        SimpleDate sd1 = new SimpleDate(13, 1, 2004);
        System.out.println(sd1);
    }
}