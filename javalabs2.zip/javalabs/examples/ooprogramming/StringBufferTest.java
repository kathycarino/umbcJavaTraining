package examples.ooprogramming;
public class StringBufferTest{
    public static void main(String args[]){
    	StringBuffer sb = new StringBuffer();
        System.out.print("length:" + sb.length());
        System.out.println(" cap:" + sb.capacity());
        System.out.println();
        sb.append(123456789);
        System.out.println(sb.toString());
        System.out.print("length:" + sb.length());
        System.out.println(" cap:" + sb.capacity());//still 16 because it didn't need to grow
        System.out.println();
        sb.insert(0, "abcdefghi"); //starting at position 0 insert "abcdefghi" (shifts everything else to the right)
        System.out.println(sb.toString());
        System.out.print("length:" + sb.length());
        System.out.println(" cap:" + sb.capacity()); //this is 34 because 16 + 18 = 34
        System.out.println();
        sb.replace(2, 5, "Hello");
        System.out.println(sb.toString());
        System.out.print("length:" + sb.length());
        System.out.println(" cap:" + sb.capacity()); //this is still 34 because you didn't need any more space
        System.out.println();
        
        //If you knew your initial capacity is a certain character length then set that
        //when you initialize it, like so:
        //StringBuffer sb = new StringBuffer(100);
    }
}