package examples.intro;
public class Wrong {
    public static void main() {
        int x = 10, y = x * 2;
        System.out.println(x + y + " is " +  x + y);
    }
}