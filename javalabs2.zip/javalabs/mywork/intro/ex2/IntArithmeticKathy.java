package mywork.intro.ex2;

public class IntArithmeticKathy {
    public static void main(String args[]) {
        int a = 17, b = 4, c; //lookee here - you declared 3 variables on one line! 
			      //This only worked because all 3 are the same data type (int)
			      //only a and be are initialized, c is not.
			      //you could have put c = a + b on the same line, but those weren't
			      //the directions :-)
	c = a + b;
	System.out.println(a + " + " + b + " = " + c);
	
	//The above code was given to you on page 1-14, you just had to make sure you
	//named your class appropriately and added the package line appropriately,
	//now let's play around reusing the variable c to use / (divide) and % (modulus - remainder)
	
	c = a / b;
	System.out.println("a divided by b equals " +c);
	//but wait a minute - when you run this 17/4 = 4?! Well, that's because it's an int, can't
	//put a decimal in an int (try a float and see what you get).
	
	c = a % b;
	System.out.println("and the remainder is " +c);

	int x = 10;
	System.out.println(x++); //will be 10
	System.out.println(++x); //will be 12
	System.out.println(x--); //will be 12
	System.out.println(x); //will be 11
	

    }

}