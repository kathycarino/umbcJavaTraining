package mywork.language.ex2;

public class NestedFor {

	public static void main(String[] args) {
		for (int i = 1; i <= 7; i = i + 1){ //start i loop
//			System.out.println(i);
			for (int j = i; j >= 1; j = j -1){ //start j loop
				System.out.print(j + " ");
			} //end j loop
			System.out.println();
		}//end i loop

	}//end main method

}//end NestedFor class

