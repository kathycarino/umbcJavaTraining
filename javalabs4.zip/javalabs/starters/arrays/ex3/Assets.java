package starters.arrays.ex3;
public class Assets{
    // instance variables
    String names[];
    double values[];
    int size, capacity;

    // constructor
    public Assets(int maxSize){
        // **** TODO ***
    }

    // methods

    // add an item and its value to this object
    public void addElement(String item, double itemVal){
        // **** TODO ***
    }

    // number of items currently stored
    public int size(){
        // **** TODO ***
        return 0;
    }

    // number of items capable of storing
    public int capacity(){
        // **** TODO ***
        return 0;
    }

    // total dollar value of all assets being tracked
    public double getTotalValue(){
        // **** TODO ***
        return 0.0;
    }

    // name and value of a particular item
    public String getItem(int whichitem){
        // **** TODO ***
        return null;
    }

    // table of item names and values
    public String toString(){
        // **** TODO ***
        return null;
    }
}