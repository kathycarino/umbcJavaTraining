package mywork.inheritance.ex1;

public class Appointment extends SimpleDate {

	private String place;
	private String person;
	
	public Appointment(int m, int d, int y, String place, String person){
        super(m, d, y);						
        									
        this.place = place;
        this.person = person;
    }

    public String getPlace() {
        return place;
    }
    
    public String getPerson() {
        return person;
    }
}
