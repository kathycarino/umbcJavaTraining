package mywork.inheritance.ex1;

public class Holiday extends SimpleDate {

	private String name;
	
	public Holiday(int m, int d, int y, String name){
        super(m, d, y);						
        									
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
