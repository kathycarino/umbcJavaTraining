package mywork.ooprogramming.ex4;

import java.util.Date;

public class SimpleDate {
	
	int d, m, y; //instructor told me this bad - call it day, month, year

	//this constructor is for when the user supplies the month, day, and year
	public SimpleDate(int m, int d, int y) {
		this.m = m;
		this.d = d;
		this.y = y;
		//no more work to be done since user supplied all three
	}
	
	//this constructor is for when the user supplies only the month and day
	public SimpleDate(int m, int d) {
		this.m = m;
		this.d = d;
		Date now  = new Date();
	    this.y = now.getYear() + 1900;
	    
	}
	
	//this constructor is for when the user supplies only supplies the day, so you have to get month and year
	public SimpleDate(int d) {
		this.d = d;
		Date now = new Date();
		this.m = now.getMonth() + 1;
		this.y = now.getYear() + 1900;
	}
	
	//this constructor is for when the user does not supply anything
	public SimpleDate(){
		Date now = new Date();
		this.d = now.getDate();
		this.m = now.getMonth() + 1;
		this.y = now.getYear() + 1900;
	}

	public int getD() {
		return d;
	}

	public int getM() {
		return m;
	}

	public int getY() {
		return y;
	}

	public void setD(int d) {
		this.d = d;
	}

	public void setM(int m) {
		this.m = m;
	}

	public void setY(int y) {
		this.y = y;
	}

	public String toString() {
        return  m + "/" + d + "/" + y;
    }

	//instructor refactoring below, make this simpler by making a helper method
	//this is an example of a method that should not be public, i don't want anybody
	//else calling my method, only want it called inside my constructors, so make it private
/*	public SimpleDate(){
		this.helper(); //so inside your constructor, call you helper like this helper();
	}
	
	public void helper(){ //change this to private, see notes above
		Date now = new Date();
		this.d = now.getDate();
		this.m = now.getMonth() + 1;
		this.y = now.getYear() + 1900;
	}*/
}
