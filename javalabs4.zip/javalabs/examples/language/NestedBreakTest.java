package examples.language;

//curly braces are optional but look how ugly this is.
/*public class NestedBreakTest {
    public static void main(String args[]) {
        int i,j;
outer:  for (i = 0; i < 10; i++)
           for ( j = 0; j < 10; j++)
              if ( i + j > 15 )
                 break outer;
        System.out.println("i is "  + i);
    }*/

/*Example using labels
public class NestedBreakTest {
      public static void main(String args[]) {
            int i,j;
    outer:  for (i = 0; i < 10; i++){ // outer is a label to help you break out
               for ( j = 0; j < 10; j++){
                  if ( i + j > 15 ){
                     break outer;
                  }
               } //end of j loop
             } //end of i loop
            System.out.println("i is "  + i);
        }
}*/

//Example using boolean flag
public class NestedBreakTest {
      public static void main(String args[]) {
            int i,j;
            boolean keepGoingFlag = true;
   			for (i = 0; i < 10; i++){ 
               for ( j = 0; j < 10; j++){
                  if ( i + j > 15 ){
                  	keepGoingFlag = false;
                     break;
                  } //end of first if
               } //end of j loop
               if (!keepGoingFlag){
               		break;
               } //end of second if
            } //end of i loop
            System.out.println("i is "  + i);
        } //end of main
} //end of class