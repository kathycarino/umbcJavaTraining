//Refer to page 5-10
package examples.arrays;
import java.util.Arrays;							//
public class ManipulateArrays {
    public static void main(String args[]){
        int x [] = {3, 7, 1, 9, 2, 10};				//here is my array of ints
        String s [] = {"Mike", "Alan", "Susan"};	//here is my array of strings
        printArray(x);
        printArray(s);
        System.out.println("\nSorted Order");
        Arrays.sort(x);								//the Arrays class has a sort method sorting from low to high
        Arrays.sort(s);								//sorts legicographically. Note you can't sort everything, you can sort primitives 
        											//and strings, you can't sort your Points for example.
        printArray(x);
        printArray(s);
        System.out.print("Filling an array:    ");
        Arrays.fill(s, "NotUsed");					//will overwrite everything in the array with NotUsed, so be careful using fill!
        printArray(s);
    }
    public static void printArray(int a[]){
        for(int i = 0; i < a.length; i++)
            System.out.print(a[i] + " ");
        System.out.println();
    }
    public static void printArray(String s[]){
        for(int i = 0; i < s.length; i++)
            System.out.print(s[i] + " ");
        System.out.println();
    }
}