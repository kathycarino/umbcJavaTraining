package examples.methods;
import java.util.Date;

public class SystemStuff {
    public static void main(String args[]) {
        long t1 = System.currentTimeMillis();  
        System.out.println("ms = " + t1);

        Date today = new Date(t1);
        System.out.println("Today is: " + today);

        if(Math.random() < .5){
            String s = "JVM terminating early";
            System.out.println(s);
            System.exit(1); //pass int to exit method, anything other than 0 is failure, to see this in Windows
            				//you can "echo %ERRORLEVEL%
        }

        long day = 1000*60*60*24; //number of ms in a day
        Date tomorrow = new Date(t1 + day);
        System.out.println("Tomorrow: " + tomorrow);

        long t2 = System.currentTimeMillis(); 
        System.out.println("# of ms: " + (t2-t1)); //so what's the difference? how long did it take to run?

        System.out.println("JVM terminating");
    }
}