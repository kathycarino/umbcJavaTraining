package examples.methods;
public class BorderPrinter {
    public static void main(String args[]){
        String s = "Border Printer";
        BorderPrinter.boxIt(s);  //here is my call to the static method, must have ClassName.method if it was defined in a different Class
        						//since this is in this same class, you really didn't need it - see line 8. See MessagePrinter.java for another example.
        s = "Place a border around this also";
        boxIt(s); //Eclipse uses italics to show you this is a static method.
    }

    public static void boxIt(String data){ //example of a static method, up until now we've been using instance methods.  
    									   //Instances methods are associated with objects and, as the name implies, can use instance variables.
    									   //I don't need to store the value, maintain state, etc..., so static method will be fine
        int len = data.length();
        for(int i = 0; i < len + 4; i++){
            System.out.print('*');
        }
        System.out.println();
        System.out.println("* " + data + " *");
        for(int i = 0; i < len + 4; i++){
            System.out.print('*');
        }
        System.out.println('\n');
    }
}