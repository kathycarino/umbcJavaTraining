package examples.exceptions;
public class PrintHello {
    public static void main(String args[]) {
        while(true) {
            System.out.println("hello");
            Thread.sleep(2000);
        }
    }
}