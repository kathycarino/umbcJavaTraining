//Instructor:  Inheritance and Polymorphism - see Chapter 7
//Dave is a person, can go by Mr. Flanagan or Dave or Dave Flanagan.  He's morphing around. Inheritance:  E.g., Object -> Person -> Flanagan -> Dave
//override methods - if you don't like the method your parent gives you, make your own to override it. E.g., Dave didn't like the getShoes method his parents
//gave him because too cheap, he wrote his own getShoes method and first thing it did was call getJob.
package examples.inheritance;
public class Point3D extends Point {	//Since you already have a Point, let's derive Point3D from it since it's got everything a Point has plus more.
										//by using "extends" you get everything in the Point class, but remember, you don't get the data!
    private int zc;	//this makes Point3D special - it's got another coordinate

    public Point3D(int xc, int yc, int zc){
        super(xc, yc);						//I can't reference the data directly since it's not mine, but I can use super to get to it. This basically
        									//goes to your Point.java's constructor.
        this.zc = zc;
    }

    public int getZc() {
        return zc;
    }

   //say you tried this first?  Would it work?  No, it would fail - you don't have direct access to xc and yc
  //  public String toString() {
 //       return xc + "," + yc + "," + zc; 
    
    public String toString() {					//method overriding because Point has it's own toString method that works differently, 
    											//but you want to use it plus add some stuff
        return super.toString() + "," + zc;
    }
}