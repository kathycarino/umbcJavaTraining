//See page 6-19
package examples.encapsulation;
public class Account {
    private static int counter = 1000;	//static data is only initialized once and is loaded into memory by Java when Java first loads the class into memory (only once)
    									//so it happens before any object of that class is even instantiated.
    private String name;
    private int accountNum;
    public Account(String n) {	//here's my constructor
        name = n;
        accountNum  = counter++;	//so accountNum is based off a static variable called counter - it can be updated as we see here
    }
    public String toString() {
        return name + " has account # " + accountNum;
    }
    public static int nextNumber() {
        return counter;
    }
}