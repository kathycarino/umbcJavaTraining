//You get a constructor for "free" by the compiler if you don't write one.  it does not take any arguments.  You could write
//EncapsulationNotes notes = new EncapsulationNotes() and it would compile (wouldn't do anything, but
//it would compile). You can do system.out.println(notes.toString()); and it will compile because
//you got toString from your parent (inheritance). See EncapsulationNotesTest.
//Note that once you define constructors if you need one that doesn't take arguments you have
//to write your own, you no longer get it for free.

//Now look at Point.java - let's walk through page 6-4, there is a 3 step process:
//1. Sets values in array to 0
//2. Initializes values to 1 (from Point.java constructor)
//3. Sets them to what you set them to when you call new (like say you do Point p = new Point (9, 20);)

//Page 6-6, you need to use "this" when there is ambiguity, if there is a local variable and instance variable
//of the same name.  Now let's look at a method call this() - see page 6-8 and go to Circle.java.

//Page 6-10 - Data Hiding/Private/Public/Inheritance
//private, public, protected, "packagelevel" - see pg 6-15.
//Instructor analogy - house growing up was "private", only parents could access it with a key. But after the kids got older
//they gave them keys so they changed from "private" to "packagelevel" (not public, don't want just anybody entering).
//Dave could only get in by using the public accessor method (knocking on the door). "packagelevel" because they all live in the same
//house, you don't get a key unless you live in the same house. But then they gave keys to their children when they moved out of the house
//so it's changed to "protected".  Always in your best interest to hide your data. You can't understand protected without understanding
//inheritance.

package examples.encapsulation;

public class EncapsulationNotes {

}
