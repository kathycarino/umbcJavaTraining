package examples.ooprogramming;
import java.text.DecimalFormat;//analogy: this of this as a formatter like when you use Excel to convert numbers to text or certain formats
								//instructor mentioned you can use printf but this is easier, this will format numbers as text
public class DecimalFormatTest {
    public static void main(String args[]) {
        double value1 = 10000/6.0;
        int value2 = 25;
        DecimalFormat dfA = new DecimalFormat(".##");//this is the format you want - two digits
        DecimalFormat dfB = new DecimalFormat(".00");//two digits showing 00s
        DecimalFormat dfC = new DecimalFormat(".###");
        DecimalFormat dfD = new DecimalFormat("##,###.##");
        DecimalFormat dfE = new DecimalFormat("00,000.##");

        System.out.println("This is what 10000/6.0 in value1 will look like with these different formats");
        System.out.println(dfA.format(value1));
        System.out.println(dfB.format(value1));
        System.out.println(dfC.format(value1));
        System.out.println(dfD.format(value1));//this seems weird that the format has .## at the end but doesn't put .0 like dfA did. Instructor could not explain.
        System.out.println(dfE.format(value1));
        System.out.println();
        System.out.println("This is what 25 in value2 will look like with these different formats");
        System.out.println(dfA.format(value2));
        System.out.println(dfB.format(value2));
        System.out.println(dfC.format(value2));
        System.out.println(dfD.format(value2));//this seems weird that the format has .## at the end but doesn't put .0 like dfA did. Instructor could not explain.
        System.out.println(dfE.format(value2));

    }
}