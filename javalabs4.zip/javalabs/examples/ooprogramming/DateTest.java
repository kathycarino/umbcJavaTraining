package examples.ooprogramming;
import java.util.Date; //you can wildcard this "import java.util.*:" - IT DOES NOT MEAN YOUR LOADING ALL OF THEM, you're
					   //just saying you might want to use something later, once you use it it loads it, but this
					   //might make your code harder to read and some companies will say you can't do this
public class DateTest {
    
	public static void main(String args[]) {
        Date now = new Date(); //notice you didn't need to say "java.util.Date now" because you used an import
        System.out.println(now.toString());//this is duplicative of the next line
        System.out.println(now);//passing an object will automatically call that object's toString so you don't have to
        						//note: the println method is "overloaded" (lots of println methods with slight variations)

        System.out.print("Day of the Week: ");
        System.out.println(now.getDay()); //these are deprecated warnings so they are recommending you might want
        								  //to use a different method in case they finally get removed

        System.out.print("Day of the Month: ");
        System.out.println(now.getDate());

        System.out.print("Month: ");
        System.out.println(now.getMonth());

        System.out.print("Year: ");
        System.out.println(now.getYear()); //Jan 1, 1900 is the date Sun chose to track years from
        System.out.println(now.getYear()+1900); //I added this so you can see the real year.

        System.out.print("Time: ");
        System.out.println(now.getTime()); //this returns # of ms since Jan 1, 1970 (birth of Unix)
    }
}