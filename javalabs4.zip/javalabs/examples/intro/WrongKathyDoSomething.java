package examples.intro;
public class WrongKathyDoSomething{
    public static void main(String args[]) {
        WrongKathy.doSomething();
    }
}