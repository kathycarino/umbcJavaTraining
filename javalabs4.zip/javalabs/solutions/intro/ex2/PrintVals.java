package solutions.intro.ex2;
public class PrintVals {
    public static void main(String args[]){
        int a  = 17, b = 4, c;

        c = a + b;
        System.out.println(a + " + " + b + " = " + c);

        c = a / b;
        System.out.println(a + " / " + b + " = " + c);

        c = a % b;
        System.out.println(a + " % " + b + " = " + c);
    }
}