//This causes a lot of compile errors for you to fix
//package starters.intro.ex1;
//Public Class MyNewClass {
//    public void static main(String s){
//        integer a = 5
//        system.out.println("a = ", a);
//    }
//}