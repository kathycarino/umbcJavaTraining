package mywork;

public class CastingIssues {

	public static void main(String[] args) {
//		byte b = 127;
//		b = b +1; //can't compile
//		b = (byte) (b +1); //this will compile because you cast as a byte but may not be what you really want
//		System.out.println(b); //this is valid but you will see -128 (negative - wraps all the way around because can't go higher than 127 for byte.
//								//tip:  type syso and then ctrl-space will give you the whole method
//								//tip: ctrl plus fwd slash will comment block selected
		
		byte b=127;
		//b = b + 1;
		b++; //will compile but still same problem
		System.out.println(b);

	}

}
