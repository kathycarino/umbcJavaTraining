package mywork.ooprogramming.ex4;

//you don't need an import here for your SimpleDate class because it's in the same package.  If you use someone else's, you need an import!
//want to know what arguments, methods, etc... are available to you? Check the javadoc - if no javadoc has been created yet, simply
//use eclipse to generate (right-click and export...)

public class SimpleDateTest {

	//This is for sd1 - user only supplies all three
	public static void main(String[] args) {
		SimpleDate sd1 = new SimpleDate(12, 31, 2004); 
		System.out.println(sd1.toString());

	
	//This is for sd2 - user only supplies month and day
	//constructor will determine the year
	    SimpleDate sd2 = new SimpleDate(10,31); 
	    System.out.println(sd2.toString());
	    
	//This is for sd3 - user only supplies day
	//constructor will determine the month and year
	    SimpleDate sd3 = new SimpleDate(15); 
	    System.out.println(sd3.toString());

	  //This is for sd4 - user did not supply anything
		    SimpleDate sd4 = new SimpleDate(); 
		    System.out.println(sd4.toString());
	

		}
	}