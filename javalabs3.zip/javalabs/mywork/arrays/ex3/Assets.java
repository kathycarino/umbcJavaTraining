package mywork.arrays.ex3;

public class Assets {
	//kind of like a string buffer, set capacity to maxSize, addElement to the size, size and capacity are getters, loop through doubles array and get running total
	//don't forget \n so they print out on their own lines, use starter code
	//could use growable assets with array copy? (extra challenge)
}
