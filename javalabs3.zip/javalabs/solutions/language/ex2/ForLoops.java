package solutions.language.ex2;
public class ForLoops {
    public static void main(String args[]) {
 //       for ( int i = 1; i <= 7; i = i++) { /This was my typo that caused an infinite loop because it performs the ++ after the i, so i still equals itself all the time
        for ( int i = 1; i <= 7; i++) {
            for (int  j = i; j >= 1; j-- ) {
                System.out.print(j + " " );
            } // end for j loop
            System.out.println();
        } // end for i loop
    } // end of main
}