package starters.inheritance.ex2;
public class Planner{
    private SimpleDate sd [];
    private int capacity;
    private int size;

    public Planner(int capacity){
        // **** TODO ***
    }

    public int getCapacity(){
        // **** TODO ***
        return 0;
    }

    public int getSize(){
        // **** TODO ***
        return 0;
    }

    public void addDate(SimpleDate d){
        // **** TODO ***
    }

    public String toString(){
        // **** TODO ***
        return null;
    }

    public Appointment [] getAppointments(){
        // **** TODO ***
        return null;
    }

    public Holiday [] getHolidays(){
        // **** TODO ***
        return null;
    }
}