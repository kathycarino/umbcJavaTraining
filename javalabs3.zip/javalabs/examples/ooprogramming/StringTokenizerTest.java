package examples.ooprogramming;
import java.util.StringTokenizer;  //purpose is to break apart a string into different strings called "tokens" - can also use "split" (easier)
public class StringTokenizerTest {
    public static void main(String args[]) {
        String text = "Mon Tue Wed Thu Fri Sat Sun"; //this has white space separating, so you don't need to give a delimiter as an argument
        StringTokenizer st; //pass that string to the "constructor" StringTokenizer
        st = new StringTokenizer(text);
        while(st.hasMoreTokens()) {  //can't always use a while loop because normally you would want to put the tokens in separate variables like month, day, year
            System.out.println(st.nextToken());
        }

        System.out.println("---------------");

        text = "Data,More Data-StillMoreData";
        st = new StringTokenizer(text, ",-"); //overloaded constructor - see? you can use the StringTokenizer with two arguments with the delimiter as the second one (,-)
        int numTokens = st.countTokens();
        for(int i = 0; i < numTokens; i++){
            System.out.println(st.nextToken());
        }
    }
}