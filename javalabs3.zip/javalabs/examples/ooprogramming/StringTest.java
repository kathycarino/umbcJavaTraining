package examples.ooprogramming;
public class StringTest {
    public static void main(String args[]) {
    	
    	//Since you might want to use this a lot, factor it into a method and call it from every main you want to use it instead of within main
    	
    	//A String object is just a collection of characters!

        //if you don't use the new keyword you will not be guaranteed getting a new object
    	String name = new String("Michael Saltzman");
        System.out.println("Name is " + name);

        int len = name.length();
        System.out.println("length is " + len);

        int place = name.indexOf(' ');
        System.out.print("a space was found ");
        System.out.println("at position " + place);

//the substring method is an example of method overloading - there are two methods, same name, but the first one takes
//two arguments, the second one only takes one
        String first = name.substring(0, place); //substring method taking 2 arguments
        System.out.println("First Name is " + first);

        String last = name.substring(place + 1); //substring method taking 1 argument
        System.out.println("Last Name is  " + last);

        char firstNameInit = first.charAt(0);
        char lastNameInit  = last.charAt(0);

        System.out.println("Initials are " +
            firstNameInit + lastNameInit);
        
    }
}