package examples.methods;
import java.util.*;
public class MessagePrinter {
    public static void main(String args[]){
        String s = "Static Method Demo";
        BorderPrinter.boxIt(s); //now the ClassName in front of the boxIt method is required because it doesn't exist here
        String msg = "message to be converted";
        titleCase(msg); //calling static method titleCase with msg
        msg = "another simple message";
        titleCase(msg);
    }
    public static void titleCase(String s){ //receiving msg in s - get it?
        StringTokenizer st = new StringTokenizer(s); //see s again? you are passing it (your msg from main) to the StringTokenizer
        String tmp;
        String first;
        while(st.hasMoreTokens()){
            tmp = st.nextToken();
            first = tmp.substring(0,1).toUpperCase();
            System.out.print(first);
            System.out.print(tmp.substring(1) + " ");
        }
        System.out.println();
    }
}

//What happens if you have someMethod(Object o) and you want to pass in a primitive?  Create an object for it?  That object
//"wraps" your primitive.
//public class MyInt{
//	int x;
//public MyInt(int x){
//	this.x = x
//}
//int x = 10;
//MyInt m = MyInt(x);
//someMethod(m)
//Sun gives you wrapper classes for all the primitive datatypes (e.g., Integer class), they have static methods like parseInt to convert a String to an int
//see page 4-15
//Example from whiteboard:
//String name = "Dave Flanagan";
//int position = name.indexOf(' ');
//String fn = name.substring(0, position);
//String ln = name.substring(position + 1);
//********new example*******
//StringTokenizer st = newStringTokenizer(name);
//********new example*******
//String f = st.nextToken();
//String elle = st.nextToken();