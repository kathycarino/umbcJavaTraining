package examples.arrays;
public class PassAnArray {
    public static void main(String args[]) {
        int [] x = { 1, 2, 3, 4, 5}; //heads up! you can't break this into two statements!
        							 //remember! you have only one array in here - this one. x and p are references to the array object.
        							//refer to page 5-6
        print(x);
        multiply(x, 3); //x is a reference to the array, i'm passing x to multiply
        print(x);
    }
    public static void multiply(int [] p, int val){ //p contains the array reference (passed from x)
        for(int i = 0; i < p.length; i++)
            p[i] *= val;
    }
    public static void print(int [] p) {  //here's my print method that prints an array x comes in as p. p is an array of ints.
        for(int i = 0; i < p.length; i++)
            System.out.print(p[i] + " ");
        System.out.println();
    }
}
//Instructor Demo to replace print method above (ENHANCED FOR LOOP)
//public static void print(int [] p) {  
//	for (int number: p){ 					//FOR EVERY ELEMENT THAT IS IN P STORE IT IN THIS TEMPORARY VARIABLE
//    System.out.print(number + " ");
//	}


//Instructor Demo at beginning of Arrays lecture:
//int x [] = {10, 20, 30, 40, 50, 60, 70}; //you have an array with 7 ints and position 2 has value 30
//int y [] = {-5, -4, -3, -2};
//x = y //what happens here? Remember that x and y are just references to their respective arrays of int. The OBJECT size is not allowed to change, but x and y are
//not the object - they are reference to the object, so x's reference just got changed to y's reference
//so the array of -5, -4, -3, -2 is the only array left and x and y both point to it, we lost the 7 int array, see page 5-3 and 5-4.
//so you want to really copy an array, not just copy the reference to the array?  Use System.arraycopy, see page 5-5.
