package examples.arrays;
public class OffByOne {
    public static void main(String args[]) {
        for (int i = 0; i <= args.length; i++)
            System.out.println(args[i]);
    }
}

//Gives you out of bounds exception, click on the exception and goes right to the line eclipse thinks you messed up on