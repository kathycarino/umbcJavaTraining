package examples.intro;
public class AddIntegers {
    public static void main(String args[]) {
        int x = 10;
        int y = 20;
        System.out.print("Sum of ");
        System.out.print(x);
        System.out.print(" and ");
        System.out.println(y);
        System.out.print("is ");
        System.out.println(x + y);
    }
}