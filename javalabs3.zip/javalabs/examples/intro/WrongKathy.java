package examples.intro;
public class WrongKathy {
    public static void doSomething() {
        System.out.println("Do Something");
    }
}