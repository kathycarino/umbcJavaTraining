package examples.intro;
public class Concatenation {
    public static void main(String args[]) {
        int x = 10, y = 20;
        System.out.println(x + y + " is " +  x + y);
    }
}