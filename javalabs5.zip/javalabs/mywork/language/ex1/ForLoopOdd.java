package mywork.language.ex1;

public class ForLoopOdd {

	public static void main(String[] args) {
		int sum = 0;
		for (int i = 1; i < 100; i = i + 2){
//			System.out.println(i);
//			System.out.println("Before adding sum is" +sum);
			sum = sum + i;
//			System.out.println("After adding sum is" +sum);

		}
		System.out.println(sum);
	}

}
