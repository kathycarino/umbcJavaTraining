package mywork.arrays.ex2;

import java.util.Arrays;

public class TemperatureConverter {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//For loop to create the table, loop on c
		//double c = 0;
		
		//System.out.println(f);
		
		int argArray [] = {0, 30, 10};	//will be passed in as argument, but easier to test for now
		
		

//		printArgs(argArray);
//		print(argArray);
//		split(argArray);
		printLoop(argArray);
	}	
		
	public static void printLoop (int[] argArray){
		int startC = argArray[0];
		int endC = argArray[1];
		int increment = argArray[2];
		double f = 1.8 * argArray[1] +32;
		System.out.println("Result of my calculation: " + f);
		System.out.println("\nStarting at: " + startC);
		System.out.println("\nEnding at " + endC);
		System.out.println("\nand Incrementing by " + increment);
		
		for (int c = startC; c <= endC; c = c + increment)
//			System.out.println(startC + " " + endC + " " + increment);
			System.out.println(c);
		
	}
	

//        System.out.println(c +"\t" + (1.8 * c + 32));
//}
	
	public static void printArgs(int[] argArray){
		System.out.println("\nJust printing the arguments received for now, bear with me");
		for(int i = 0; i < argArray.length; i++){
	            System.out.print(argArray[i] + " ");
		}
	}
		
	public static void print(int[] argArray) {  
		System.out.println("\nDon't think we need this");
		for (double number: argArray){ 					//FOR EVERY ELEMENT THAT IS IN P STORE IT IN THIS TEMPORARY VARIABLE
			System.out.print(number + " ");
		}
	}
	
	public static void split(int[] argArray){
		System.out.println("\nThis should print the contents of the Array, doesn't help me at all");
		String x = Arrays.toString(argArray);
		//System.out.println(Arrays.toString(p));
		System.out.println(x);

	}

	/*	public class SplittingHeadache {
	public static void main(Straing[] args) {
		String days = "Mon Tue Wed Thur Fri"
		String theDays [] = days.split(" ");
		System.out.println(theDays[2]); 	//or:
		for(String day : theDays){
			System.out.println(day);
		}
		System.out.println(theDays);       //Try this - you'll get an error, so do this instead:
		System.out.println(Arrays.toString(theDays)); //single statement that dumps the content of an array
	}*/

}
