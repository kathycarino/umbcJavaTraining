package mywork.inheritance.ex1;

public class HolidayAppointmentTester {
	public static void main(String args[]){

        SimpleDate dates[] = {							//an array of SimpleDates
            new Holiday(4, 16, 2017, "Today"),
            new Holiday(9, 12, 1972, "My Birthday"),
        	new Appointment(4, 20, 2017, "HeadFirst", "Nathan"),
        	new SimpleDate(5, 10, 2012)};
	        for(int i = 0; i < dates.length; i++){
	        	if (dates[i] instanceof Holiday){ 
	        		Holiday temp = (Holiday) dates[i];
	        		System.out.println(temp.getName());}
	        	else if (dates[i] instanceof Appointment){
	        		Appointment temp = (Appointment) dates[i];
	        		System.out.println(temp.getPerson());
	        		System.out.println(temp.getPlace());
	        	}
	            displayDateInfo(dates[i]);			//can take in car loan, business loan, or loan
	        }
        
	}

	private static void displayDateInfo(SimpleDate dates){	//polymorphism means this is guaranteed to work no matter the type of loan
		System.out.println("Month : " + dates.getMonth());
		System.out.println("Day   : " + dates.getDay());
        System.out.println("Year  : " + dates.getYear() + "\n");
    }

}
