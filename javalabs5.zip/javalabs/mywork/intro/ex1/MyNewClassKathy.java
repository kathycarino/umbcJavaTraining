/**
 * Exercise 1, page 1-14.  My solution
 * 
 */

package mywork.intro.ex1;

public class MyNewClassKathy {
    public static void main(String args[]) {
        int a = 5;
        System.out.println("a = " + a);
    }
}