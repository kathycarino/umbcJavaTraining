/**
 * Exercise 1, page 1-14.  Fix all the compilation errors in
 * the following program until it compiles and executes
 * without any errors. (I put my solution in MyNewClassKathy.java)
 */

This causes a lot of compile errors for you to fix
package starters.intro.ex1;
Public Class MyNewClass {
    public void static main(String s){
        integer a = 5
        system.out.println("a = ", a);
    }
}