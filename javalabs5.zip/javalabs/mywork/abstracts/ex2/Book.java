package mywork.abstracts.ex2;
public class Book implements Auctionable{
    private String title, author;
	private int condition;
	private String description;
    public Book (String title, String author, int condition, String description) {
        this.title = title;
        this.author = author;
        this.condition = condition;
        this.description = description;
    }
    public String getTitle() { return title;  }
    public String getAuthor(){ return author; }
    public String toString(){
        return title + " " + author;
    }
    public String getDescription() {				//must have these two methods to compile according to Auctionable, but need to look into frameworks
        return this.description;	//hard-coded for now
    }
    public int getCondition(){
        return this.condition;							//hard-coded for now
    }
}