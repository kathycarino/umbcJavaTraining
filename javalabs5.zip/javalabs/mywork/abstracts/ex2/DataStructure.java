//Starts on page 8-3
//You can never instantiate this class - you can't do new DataStructure
//You can instantiate it as a variable like DataStructure ds;
//IntList and IntSet are subclasses to this abstract class

package mywork.abstracts.ex2;
public abstract class DataStructure{		//see new keyword "abstract"
    // protected data:
    // only subclasses have direct access
    protected int size = 0;					//instance variables, don't want it private b/c you want your subclasses to access them

    // abstract method whose implementation
    // is left to the subclass to define
    public abstract boolean addElement(int element);	//so we know that our subclass has to have an addElement but what it does is up to the subclass

    // concrete methods that are
    // inherited by any subclass
    public boolean isEmpty(){						//we think isEmpty will work the same no matter the subclass, so we'll give them a concrete method
        return size == 0;
    }

    public int size(){					//this is basically a getter, could have called it getSize
        return size;
        
        //no toString method here because assumes you'll have one in your subclass, DataStructure doesn't know enough about you to have a toString
    }
}