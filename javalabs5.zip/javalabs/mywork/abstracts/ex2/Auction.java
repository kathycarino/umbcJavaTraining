package mywork.abstracts.ex2;
public class Auction{
    public static String [] people =
        {"Joe", "Sue", "Lynn", "Bob"};					//look into "enum" to make this easier (enumerated values)
    public static String [] conditions =
        {"New", "Like New", "Refurbished", "Used"};

    public static void main(String args[]){
    	
        Auctionable a = new Book("Harry Potter: Chamber of Secrets", "J.K. Rowling", Auctionable.LIKE_NEW, "Everyone's Favorite!");	//takes any type of "Auctionable"
        auctionIt(a);
    }
    public static void auctionIt(Auctionable item){
        double highBid = 0;
        String highBidder = null;

        // bidding process
        for(int i = 0; i < people.length; i++){
            double bid = getRandomBid();
            print(people[i] + " bidding " + bid);
            if(bid > highBid){
                highBidder = people[i];
                highBid = bid;
            }
        }
        print("------------");
        print("Auction Results:");
        print("Item: " + item);		//item is of type Auctionable (see line 12)
        print("Desc: " + item.getDescription());
        int c = item.getCondition();
        print("Condition: " + conditions[c]);
        print("HighBidder: " + highBidder);
        print("HighBid: " + highBid + "\n\n");
    }
    public static double getRandomBid(){
        int x = (int) (Math.random() * 10000);	//remember random returns a number between 0 and 1, so multiple by 10000 to shift the decimal cast into an int
        double b = x / 100.0;					//so now all your bids will be between 0 and 99
        return b;
    }
    public static void print(String s){
        System.out.println(s);
    }
}