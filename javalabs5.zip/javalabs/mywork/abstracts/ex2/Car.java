//Instructor used Car, Book, and Computer to talk about interfaces. They don't
//appear to have anything in common.  Now let's say we want to write an app
//to sell these three items (like eBay). so let's start with defining an interface
//call Auctionable (go to Auctionable.java)
package mywork.abstracts.ex2;
public class Car implements Auctionable{	//refer to page 8-12, remember you can only extend ONE class but you can IMPLEMENT as many interfaces as you want.
    private String make, model;				//if you wanted every Car to have it's own description and name, you should allow by adding to make, model, description, condition
    public Car (String make, String model) {
        this.make = make;
        this.model = model;
    }
    public String getMake() { return make;  }
    public String getModel(){ return model; }
    public String toString(){
        return make + " " + model;
    }
    public String getDescription() {				//must have these two methods to compile according to Auctionable, but need to look into frameworks
        return "Low Mileage, New tires, AM/FM/CD";	//hard-coded for now
    }
    public int getCondition(){
        return LIKE_NEW;							//hard-coded for now
    }
}