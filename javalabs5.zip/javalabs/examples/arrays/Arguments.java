//Refer 5-11
package examples.arrays;

import java.util.Arrays;

public class Arguments {
    public static void main(String args[]) {
        if ( args.length == 0 ){
            System.out.println("Need arguments");
            System.exit(1);
        }
        System.out.println("FORWARD");
        for (int i = 0; i < args.length; i++) 	//don't forget when you first instantiate your array, every place gets a 0
            System.out.println(args[i]); 		//here's your array, i is the index into your array (starting with 0)
        System.out.println("\nBACKWARD");
        for (int i = args.length - 1; i >= 0; i--)
            System.out.println(args[i]);
    }
}

//How do you run this - see cmdImage18 picture to run from command line, but you can also do it from
//eclipse - go to Run - Configuration and click on Arguments tab (warning - configuration will always
//pull up last thing you ran

//Instructor Demo using split and enhanced for loop and then the Arrays.toString, basically
//showing us 3 ways to output the same content
/*public class SplittingHeadache {
	public static void main(Straing[] args) {
		String days = "Mon Tue Wed Thur Fri"
		String theDays [] = days.split(" ");
		System.out.println(theDays[2]); 	//or:
		for(String day : theDays){
			System.out.println(day);
		}
		System.out.println(theDays);       //Try this - you'll get an error, so do this instead:
		System.out.println(Arrays.toString(theDays)); //single statement that dumps the content of an array
	}
}*/
