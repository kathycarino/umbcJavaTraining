/**
* Day 1 - Morning Continued - Packages, page 1-7 through 1-10.
* Packages are like folders
* All your classes should be in a package otherwise
* they get automatically added to the default "no name" package
* and are impossible to reference, so here's our HelloKathy class
* assigned to the examples.intro package. Look on your hard drive and you will
* see the matching directory structure. Open a DOS prompt and run your setenv script. 
* For this class, you must do this every time!
* For this class, you must compile in the directory your .java file is in. Since this new
* Hello class is in a package, you must run it using the fully qualified package name.
* See cmdImage15. Don't forget to compile first!
*/ 

package examples.intro;
public class HelloKathy {
    public static void main(String args[]) {
        System.out.println("Hello Kathy Again");
    }
}