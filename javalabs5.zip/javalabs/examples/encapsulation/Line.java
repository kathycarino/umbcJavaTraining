//page 6-16:  Composition
package examples.encapsulation;
public class Line {

    private Point p1;		//this is private, but keep in mind two Line objects can access each other's data in Java - it's private at the class level
    						//not the object level.
    private Point p2;
    private double length;

    public Line(Point p1, Point p2) {
        this.p1 = p1;
        this.p2 = p2;
        length = distance(p1, p2);  //only time I calculate the length is on instantiation?  Is this okay? Do I ever need to changet it? No, I'm good.
    }
    public Line(int x1, int y1, int x2, int y2) {   //we're providing this constructor for those that don't know about Point
        this(new Point(x1,y1), new Point(x2,y2));	//but as you see, I'm still using Point internally
    }
    private double distance(Point p1, Point p2) { //this method is private, just want to use it here to calculate based on the points given to you.
        double xd = p1.getXc() - p2.getXc();	//I don't have access to xc without going through the public accessor methods (get)
        double yd = p1.getYc() - p2.getYc();
        return Math.sqrt(xd * xd + yd * yd);
    }
    public double getLength () {
        return length;
    }
    public String toString() {
        return p1.toString()+ "; " + p2.toString();
    }
}