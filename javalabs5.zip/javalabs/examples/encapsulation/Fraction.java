package examples.encapsulation;
public class Fraction {
    private int numer, denom;

    public Fraction(int numer, int denom){
        // use of "this" is required here
        this.numer = numer;
        this.denom = denom;
    }
    public Fraction(){
        this(0,1);
    }
    public Fraction multiply(Fraction p) {
        Fraction temp = new Fraction();
        // use of "this" is optional here
        // simply used for clarity - see page 6-13, take "this" out and still works.
        temp.numer = this.numer * p.numer;
        temp.denom = this.denom * p.denom;
        return temp;
    }
    public String toString() {
        int val = this.gcd(numer, denom);  //GCD = greatest common denominator
        return numer/val + "/" + denom/val;
    }
    private int gcd(int top, int bot) {	//this method is private because the only use of it is for my toString method
        int rem;
        rem = top % bot;
        while(rem != 0) {
            top = bot;
            bot = rem;
            rem = top % bot;
        }
        return bot;
        
 /*      //Instructor Demo - refactor so you don't have to send in arguments.  He also
  * 	//demo'ed moving gcd out to a separate class but then changed it to public static or else it would have to be an
  * 	//instance method (you could only use it if you instantiated that new class's object.
        private int gcd() {	//this method is private because the only use of it is for my toString method
            int rem;
            int top = numer;
            int bot = denom
            rem = numer % denom;
            rem = top % bot;
        while(rem != 0) {
            top = bot;
            bot = rem;
            rem = top % bot;
        }
        return bot;*/
    }
}
