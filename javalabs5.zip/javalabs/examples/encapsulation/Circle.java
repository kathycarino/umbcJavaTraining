package examples.encapsulation;
public class Circle {
    private int xc, yc, radius; //This data is private, nobody can access it outside this class, to make it packagelevel access than remove the word "private"
    
    //the if statement is an example of YOU controlling the data that is passed to you. You made Circle public, but they have to pass you the data
    //and you are controlling the data (you don't want a bad radius).
    public Circle(int x, int y, int rad){
        xc = x;  //example - this is available to anybody in the same package
        yc = y;
        if(rad < 0){
            print("Bad radius: " + rad);			//look at "print" - what is that? you know it must be a method IN THIS CLASS so scroll down and you'll see it
            print("Default value of 1 being used");
            rad = 1;
        }
        radius = rad;
    }
 
    //look at the repetition on page 6-8 where every constructor set the three values with three lines,
    //why not use this and do it on one line like below?  HOw does this work?
    //Let's say you call the constructor that takes two arguments new Circle (3,4) - it will go to the one right
    //below me, but see the this has three arguments? So it will pass 3,4,1 to the constructor above
    //that takes three arguments.
    //Also - remember you can't have a constructor that takes the same # and type of arguments
    //as another constructor, so you can't pass in xc and radius.
    public Circle(int x, int y) {
        this(x, y, 1);
        //could have other stuff here, but this must always be first.
    }
    public Circle(int rad) {
        this(0, 0, rad);
    }
    public Circle() {
        this(0, 0, 1);
    }
    public double calcArea() {
        return Math.PI * radius * radius;  //PI is a static variable because it's with the class not the object
    }
    public String toString() {
        return xc + "," + yc + ": rad = " + radius;
    }
    public int getXc(){
        return xc;
    }
    public int getYc(){
        return yc;
    }
    public int getRadius(){
        return radius;
    }
    public void setRadius(int r){		//This method is public so you can change the radius even though the data is private (up top)
    									//If I didn't have this setter, than Circle would be read-only, you'd be able to initialize your circle, but never change the radius
        if(r < 0){
            print("Bad radius: " + r);
            print("radius " + radius + "unchanged" );
            return;
        }
        radius = r;
    }
    private void print(String msg){	//this method is private so you can't use it outside this class
        System.out.println(msg);
    }
}