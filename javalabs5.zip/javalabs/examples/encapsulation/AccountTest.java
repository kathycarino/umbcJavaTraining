//See page 6-19
package examples.encapsulation;
public class AccountTest {
    public static void main(String args[]) {
        System.out.print("Next # is ");
        System.out.println(Account.nextNumber());
        
        //Refactored code so you're not hard-coding:
        int quantity = args.length;
		Account workers [] = new Account[quantity];
        for(int i = 0; i < quantity; i++){
        	workers[i] = new Account(args[i]);
        }
        for (int i = 0; i < quantity; i++)
            System.out.println(workers[i]);
        
        
        
        //Original code before refactoring:
 /*       Account workers [] = { new Account("Mike"),
                               new Account("Susan"),
                               new Account("Alan") };
        for (int i = 0; i < workers.length; i++)
            System.out.println(workers[i]);*/
        System.out.print("Next # is ");
        System.out.println(Account.nextNumber());
    }
}