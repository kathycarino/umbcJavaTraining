package examples.methods;

//a class defines a new data type, this is my Loan data type
//remember what a method looks like:
//modifier return_type name(parameter_list) {
	//body of mtheod
//}
//Many use the term parameter and argument interchangeably but really:
//parameter = define what your method takes
//argument = what someone passes to your method (so remember - you need two people to have an argument :-)
//note on getters - always "get" except for booleans use "is" (example not shown here).
//signature of the method = method name, parameters, return

public class Loan {
    String name;
    double amount, rate;
    int years;

    public Loan(String n, double a, double r, int y){
        name = n;
        amount = a;
        rate = r;
        years = y;
    }
    public void assume(Loan source){  //passing a Loan object EXPLICITLY, so there are two loans - the implicit one and the explicit 
    								  //one called source, see AssumeLoan.java
        double temp = source.amount; //LoanB's amount
        amount = amount + temp; //LoanA is what the assume method was called on so amount is LoanA's amount (like stating this.amount),
        						//so your adding LoanB's amount to LoanA's amount and put it back in LoanA
        source.amount = 0.0;	//remember source is LoanB's amount, so now LoanB's amount is zero. Run AssumeLoan and you will see what I'm talking about
        						//make sure you understand the difference between working with a primitive like int vs an object, you get a copy of the reference
        						//to an object, you get an actual copy of the primitive with a primitive.
    }
    public String toString(){
        StringBuffer sb = new StringBuffer(); //instructor mentioned StringBuilder class - same methods, but StringBuffer is thread-safe
        									  //so use StringBuilder if you know you don't have threads because it's faster
        									  //analogy: you don't need a lock on your bathroom if you live alone, pain to find the key and
        									 //unlock the door every time you need to go, you know you're the only one using it.
        sb.append(name); //name is coming from this loan object like this.name, the passing of the loan object to toString is IMPLICIT
        sb.append(", ");
        sb.append(amount);
        sb.append(", ");
        sb.append(rate);
        sb.append(", ");
        sb.append(years);
        return sb.toString();
    }
    public void setName(String n) {
        name = n;
    }
    public void setAmount(double a) {
        amount = a;
    }
    public void setRate(double r) { //why setters? because you might need to change the value. Using this method as an example,
    								//if I want to use it, I have to instantiate a Loan object and pass in a double to this method
    								//double defaultAPR = 8.0;
    								//Loan myLoan = new Loan();
    								//myLoan.setRate(defaultAPR);
        rate = r;
    }
    public void setYears(int y) { //let's think about how primitives work, using our y here as an example, see page 4-4. Here's an example:
    							  //SomeObject.someMethod(x);
        years = y;
    }
    public String getName() {
        return name;
    }
    public double getAmount() {
        return amount;
    }
    public double getRate() {
        return rate;
    }
    public int getYears() {
        return years;
    }
}