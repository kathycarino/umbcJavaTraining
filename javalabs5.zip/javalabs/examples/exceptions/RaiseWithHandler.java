//Added exception handling to Raise.java
//since you didn't really handle the exceptions (you just caught them and printed something) then it will let
//the JVM handle the exception.
package examples.exceptions;
public class RaiseWithHandler {
	public static void main(String args[]) {
		double base, expo, result;

		try {
			base = Double.parseDouble(args[0]);
			expo = Double.parseDouble(args[1]);
			result = Math.pow(base, expo);
			System.out.println(result);
			// } catch(NumberFormatException nfe) {
			// System.out.println(nfe);
			// } catch(ArrayIndexOutOfBoundsException ai) {
			// System.out.println(ai);
			// above, in both catch blocks you're handling the exception the
			// exact same way - you're calling it's toString method.
			// Refactored:
		} catch (Exception e) {
			System.out.println(e);
		} finally {
			System.out.println("Inside of finally");
		}
		System.out.println("Finished with handlers");
	}
}

////Instructor Demo:
//	package examples.exceptions;
//	public class RaiseWithHandler {
//	    public static void main(String args[]) {
//	        try {
//	            a(args);
//	        } finally {
//	            System.out.println("Mains finally");
//	        }
//	        System.out.println("All systems go");
//	    }
//	    
//	    public static void a(String[] args) {
//	    	something(args);
//	    }
//	    
//	    public static void something(String args[]){
//	    	try{
//	    		System.out.println(args[0]);
//	    	} catch(Exception nfe) {
//	    		System.out.println(nfe);
//	    	} finally {
//	    		System.out.println("Inside of finally");
//	    	}
//	    	System.out.println("Finished with handlers");
//	    	}
//	    }
	