package examples.collections;
import java.util.Vector;
public class VectorTest {					//think of this like a growable array of objects, if you're not using threads, you can use ArrayList
    public static void main(String args[])  {
        Vector v = new Vector(100);			//array with length (initial capacity) of 100
        print("SIZE = " + v.size());
        print("CAPACITY = " + v.capacity());
        Integer x = new Integer(10);	//wrap the integer into Integer object so you can add it
        v.add(x);
        v.add(new Double(10.5));
        v.add("Mike");

        print("SIZE = " + v.size());
        for (int i = 0; i < v.size(); i++)
            print(v.get(i));			//returns an object.

        print(x + " at pos: " + v.indexOf(x));
        print(v);
        v.remove(1);
        print(v);
    }
    public static void print(Object o){
        System.out.println(o);
    }
}