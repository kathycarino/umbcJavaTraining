package examples.collections;
import java.util.*;
import java.io.*;
public class LoadProperties{
    public static void main(String args[])
      throws IOException{
        FileInputStream fis =
            new FileInputStream(args[0]);
        Properties p = new Properties();
        p.load(fis);						//loads every single key, value pair automatically
        fis.close();
        Enumeration e = p.propertyNames();	//get back all the keys
        String key, val;
        while(e.hasMoreElements()){			//Instructor:  what if some properties were added?  It would still read them in as key, value pairs
            key = (String) e.nextElement();
            val = (String) p.get(key);
            System.out.println(key + " " + val);
        }
    }
}