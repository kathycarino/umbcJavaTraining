//You can use HashMap instead, but then you have to use Iterator not Enumerator.
package examples.collections;

import java.util.*;

public class AccountTest {
	public static void main(String args[]) {
		Hashtable accounts = new Hashtable(); // Do this instead, specify
												// specific datatypes
												// (generics): Hashtable
												// accounts = new
												// Hashtable<Integer,
												// Account>(); so you don't
												// accidentally put something in
												// you don't want.
		// Obtain account names from command line
		Account val; // Account object named val
		Integer key; // Integer object named key
		for (int i = 0; i < args.length; i++) {
			val = new Account(args[i]);
			key = new Integer(val.getAccNumber()); // because it's a primitive
													// you have to wrap it into
													// an Object called Integer
			accounts.put(key, val); // put will only put in an object, if you
									// put a primitive, it will autobox it into
									// an Object
		}
		Enumeration e = accounts.keys(); // Do this instead Enumeration<Integer>
											// If you use this, you don't have
											// to worry about casting.
										//if using a hashmap you'd have to do 
										//Set s = accounts.keySet();
										//Iterator e = s.iterator();
		while (e.hasMoreElements()) {	//while (e.hasNext()) - and e.nextElement() becomes e.next() {
			key = (Integer) e.nextElement(); // i can cast this into an Integer
												// object because i know i'm
												// storing only integers, if
												// you're not sure have to use
												// instanceof.
			val = (Account) accounts.get(key);
			System.out.print(val.getName());
			System.out.print(" account number ");
			System.out.println(key.intValue());
		}
	}
}