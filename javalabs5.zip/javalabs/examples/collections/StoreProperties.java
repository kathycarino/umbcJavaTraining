package examples.collections;
import java.util.*;
import java.io.*;
public class StoreProperties{
    public static void main(String args[])
      throws IOException{
        FileOutputStream fos =
            new FileOutputStream(args[0]);		//take the input (a string for the filename) and put it in FileOutputStream object
        Properties p = new Properties();
        p.setProperty("fontsize", "12");		//like put
        p.setProperty("fontcolor", "green");
        p.store(fos, "header comment");			//you can do store to XML if you want a multi-line comment and then change load to loadToXML
        fos.close();
    }
}