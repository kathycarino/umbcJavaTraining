//Example for running on command line - see cmdImage19
//Instructor now demonstrating use of an interface with this - see Instructor package
//dynamic way of loading the Class as a string argument useing Class.forName(args[0])
//requires that what you want to call has to have a method that takes no argument
//"introspection and reflection"
//eclipse will complain about unhandled exceptions (what if your classname doesn't exist? what if it doesn't
//have a method that takes no arguments?)
//you can handle it by "throws Exception" and it will terminate
//Instructor did all this and then showed how he could run the code from the command line without ever changing the code
//passing in the fully qualified classname (plus the other arguments it needs)
//this would probably go in a property file.
package examples.abstracts;
public class DataStructureTest {
    public static void main(String args[]){
        DataStructure myData = new IntList(args.length);	//Now try swapping out for IntSet and see duplicates ignored. Polymorphism!
        int x;
        for(int i = 0; i < args.length; i++){
            x = Integer.parseInt(args[i]);
            myData.addElement(x);
        }
        System.out.println("Size =" + myData.size());
        System.out.println(myData);
    }
}
