//Subclass of the abstract class called DataStructure
//looks just like a basic class right?  However, this won't be able to compile until you give it an addElement method
package examples.abstracts;
public class IntList extends DataStructure {
    private int capacity;
    private int data [];

    public IntList(int capacity){
        this.capacity = capacity;
        data = new int[capacity];
    }

//  public boolean addElement(int element){ //this won't compile until you have this method because it's defined in your abstract parent DataStructure
//  if(size < capacity){				//try it! Comment this method out and see if eclipse yells at you.
//      data[size] = element;			//some people think it's bad to have two returns so you could just store the boolean in a variable and return it.
//      size++;
//      return true;
//  }
//  else
//      return false;
//}    

    //Refactored:
    public boolean addElement(int element){ 
        boolean result = false;
    	if(size < capacity){			
            data[size] = element;			
            size++;
            result = true;
        }
        return result;
    }


    
    public String toString(){
        StringBuffer sb = new StringBuffer(size * 6);	//default is 16 so come up with best guess - you know you'll have at least size and 
        for(int i = 0; i < size; i++){				//then let's guess average 6 characters
            sb.append(data[i]);
            if(i < size -1)
                sb.append(", ");
        }
        return sb.toString();
    }

}