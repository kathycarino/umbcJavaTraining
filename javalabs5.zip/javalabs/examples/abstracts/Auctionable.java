//What does your Auction app need?  It needs to get the description of the item
//and the condition of the item.  so these are your abstract methods that your class
//must have to interface Auctionable.

package examples.abstracts;
public interface Auctionable {					//only knows about types Auctionable but polymorphism makes it work.
    // available conditions
    public static final int NEW         = 0;	//these are examples of constants
    public static final int LIKE_NEW    = 1;
    public static final int REFURBISHED = 2;
    public static final int USED        = 3;

    // abstract methods to be implemented
    public String getDescription();
    public int getCondition();
}