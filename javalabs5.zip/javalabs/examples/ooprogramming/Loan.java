package examples.ooprogramming;

public class Loan {
    String name;
    double amount, rate;
    int years;
    
	//need this so you have two ways to call Loan - one requires arguments, one doesn't
    public Loan(){
		
	}

	// right-click automate your contstructor

	public Loan(String name, double amount, double rate, int years) {
		this.name = name;
		this.amount = amount;
		this.rate = rate;
		this.years = years;
	}
	//all you have to do is right-click here to automate your getters and setters (choose Source)
	/**
	 * Here i can put helpful advice on how to use my getName method
	 */
	public String getName() {
		return name;
	}
	public double getAmount() {
		return amount;
	}
	public double getRate() {
		return rate;
	}
	public int getYears() {
		return years;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setAmount(double amount) {
		this.amount = amount;
	}
	public void setRate(double rate) {
		this.rate = rate;
	}
	public void setYears(int years) {
		this.years = years;
	}
    			
     

 /*   public void setName(String n) {
        name = n;
    }*/
    
 /*   //do this instead
    public void setName(String name) {
        this.name = name;
    }
    
    
    public void setAmount(double a) {
        amount = a;
    }
    public void setRate(double r) {
        rate = r;
    }
    public void setYears(int y) {
        years = y;
    }
    public String getName() {
        return name;
    }
    public double getAmount() {
        return amount;
    }
    public double getRate() {
        return rate;
    }
    public int getYears() {
        return years;
    }*/
}