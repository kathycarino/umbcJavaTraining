package examples.language;
public class BreakTest {
    public static void main(String args[]) {
        int i;
        for ( i = 1; i <= 100; i = i + 1){
            if ( i * i > 500 ) //breaks out of the for loop and goes to System.out.println statement
                break;
        }
        System.out.println("i is "  + i);
    }
}