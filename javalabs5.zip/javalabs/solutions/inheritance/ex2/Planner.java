package solutions.inheritance.ex2;
public class Planner{
    private SimpleDate sd [];
    private int capacity;
    private int size;

    public Planner(int capacity){
        this.capacity = capacity;
        size = 0; //this is just for clarity - it's always zero on initialization - could also have done it up front on private int size = 0
        sd = new SimpleDate[capacity];
    }

    public int getCapacity(){
        return capacity;
    }

    public int getSize(){
        return size;
    }

    public void addDate(SimpleDate d){
    	//what if you want to increase your array's capacity if they run out of space?  here's the code:
    	//however, you could have just used an ArrayList and everything is simpler
        if(size >= capacity){ //could have just said = because will never be >
        	capacity *= 2;
        	SimpleDate temp [] = new SimpleDate[capacity];
        	System.arraycopy(sd, 0, temp, 0, size);
        	sd = temp; //done with old array so okay to replace it with new array
        }
        sd[size++] = d;
        
    }

    public String toString(){
        StringBuffer sb = new StringBuffer(size * 64);
        for(int i = 0; i < size; i++){
            sb.append(sd[i]);	//this will call that object's toString, this returns a StringBuffer reference to itself
            sb.append('\n');    //make sure you use single quotes so it knows it's a char (new line character is a single character)
            //sb.append(sd[i]).append('\n') //you could also do this (method chaining)
        }
        return sb.toString();	//this calls StringBuffer's toString
    }

    public Appointment [] getAppointments(){
        Appointment a [] = new Appointment [size];	//create a new Appointment array, you have to give it a size, so give it maxsize of size
        int count = 0;
        for(int i = 0; i < size; i++){
            if(sd[i] instanceof Appointment){
                a[count] = (Appointment) sd[i]; //simple dates are not allowed to go where appointments go (parents can't go where children go)
                count++;						//you could also just put count++ directly in a[count++]
            }
        }													//okay - so now can't we just return a? it's our appointment array with all the appointments?
        Appointment result [] = new Appointment[count];		//well, you could but you're passing an array that is likely to have nulls (unless all the 
        													//dates were appointments). So here you create another array to hold your non-null result
        System.arraycopy(a, 0, result, 0, count);	//a = source array, 0 = start position, result = dest array, 0 = start position, count = how many		
        return result;
    }

    public Holiday [] getHolidays(){
        Holiday a [] = new Holiday [size];
        int count = 0;
        for(int i = 0; i < size; i++){
            if(sd[i] instanceof Holiday){
                a[count] = (Holiday) sd[i];
                count++;
            }
        }
        Holiday result [] = new Holiday[count];
        System.arraycopy(a, 0, result, 0, count);
        return result;
    }

}